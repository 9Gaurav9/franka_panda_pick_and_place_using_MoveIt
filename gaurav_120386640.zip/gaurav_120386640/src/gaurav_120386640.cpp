#include <memory>
#include <utility>
#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/pose.hpp>
#include <moveit/move_group_interface/move_group_interface.h>

int main(int argc, char *argv[])
{
    // Initialize ROS node
    rclcpp::init(argc, argv);
    auto node = std::make_shared<rclcpp::Node>("gaurav_120386640", rclcpp::NodeOptions().automatically_declare_parameters_from_overrides(true));

    // Create MoveGroupInterface for both arm and gripper
    moveit::planning_interface::MoveGroupInterface arm_group(node, "panda_arm");
    moveit::planning_interface::MoveGroupInterface gripper_group(node, "panda_hand");

    // Set the target pose for the arm
    arm_group.setNamedTarget("home_pos");
    // Plan and execute the arm movement
    arm_group.move();

    // Set the target pose for the arm
    arm_group.setNamedTarget("goal_state1");
    // Plan and execute the arm movement
    arm_group.move();

    // Set the target pose for the gripper
    gripper_group.setNamedTarget("gripper_open");
    // Plan and execute the gripper movement
    gripper_group.move();

    // Set the target pose for the arm
    arm_group.setNamedTarget("goal_state2");
    // Plan and execute the arm movement
    arm_group.move();

    // Set the target pose for the gripper
    gripper_group.setNamedTarget("gripper_close");
    // Plan and execute the gripper movement
    gripper_group.move();

    // Set the target pose for the arm
    arm_group.setNamedTarget("home_pos");
    // Plan and execute the arm movement
    arm_group.move();

    rclcpp::shutdown();

    return 0;
}