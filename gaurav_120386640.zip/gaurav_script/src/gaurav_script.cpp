// #include <memory>
// #include <rclcpp/rclcpp.hpp>
// #include <trajectory_msgs/msg/joint_trajectory.hpp>
// #include <std_srvs/srv/trigger.hpp>
// #include <std_msgs/msg/string.hpp>

#include <memory>
#include <iostream> // Add this header for cout
#include <rclcpp/rclcpp.hpp>
#include <trajectory_msgs/msg/joint_trajectory.hpp>
#include <std_srvs/srv/trigger.hpp>
#include <std_msgs/msg/string.hpp>
#include <moveit/move_group_interface/move_group_interface.h>


// class PandaMotionController
// { 
// public: // This should be inside the class definition
//   PandaMotionController(rclcpp::Node::SharedPtr node)
//     : node_(node)
//   {
//     // Constructor implementation
//     // Create publishers for arm and hand joint trajectories
//     arm_joint_trajectory_publisher_ = node_->create_publisher<trajectory_msgs::msg::JointTrajectory>("panda_arm_controller/joint_trajectory", 10);
//     hand_joint_trajectory_publisher_ = node_->create_publisher<trajectory_msgs::msg::JointTrajectory>("panda_hand_controller/joint_trajectory", 10);
//   }

//   void setArmGoalState(const std::string& goal_state)
//   {
//     // Method implementation
//     trajectory_msgs::msg::JointTrajectory arm_goal_trajectory;
//     arm_goal_trajectory.joint_names = {"panda_joint1", "panda_joint2", "panda_joint3", "panda_joint4", "panda_joint5", "panda_joint6", "panda_joint7"};

//     if (goal_state == "test_pos")
//     {
//       // Set joint positions for the test position
//       arm_goal_trajectory.points.resize(1);
//       arm_goal_trajectory.points[0].positions = {1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0};
//       arm_goal_trajectory.points[0].time_from_start = rclcpp::Duration::from_seconds(2.0);
//     }
//     // Similar conditions for other goal states...
    
//     arm_joint_trajectory_publisher_->publish(arm_goal_trajectory);
//   }

//   void setHandGoalState(const std::string& goal_state)
//   {
//     // Method implementation
//     trajectory_msgs::msg::JointTrajectory hand_goal_trajectory;
//     hand_goal_trajectory.joint_names = {"panda_finger_joint1"};

//     if (goal_state == "closed_gripper")
//     {
//       // Set joint position for closed gripper
//       hand_goal_trajectory.points.resize(1);
//       hand_goal_trajectory.points[0].positions = {0.0};
//       hand_goal_trajectory.points[0].time_from_start = rclcpp::Duration::from_seconds(2.0);
//     }
//     // Similar conditions for other goal states...

//     hand_joint_trajectory_publisher_->publish(hand_goal_trajectory);
//   }

// private:
//   rclcpp::Node::SharedPtr node_;
//   rclcpp::Publisher<trajectory_msgs::msg::JointTrajectory>::SharedPtr arm_joint_trajectory_publisher_;
//   rclcpp::Publisher<trajectory_msgs::msg::JointTrajectory>::SharedPtr hand_joint_trajectory_publisher_;
// };

// int main(int argc, char * argv[])
// {
//   // Main function implementation
//   // Initialize ROS and create the Node
//   rclcpp::init(argc, argv);
//   auto node = std::make_shared<rclcpp::Node>(
//     "panda_motion_control",
//     rclcpp::NodeOptions().automatically_declare_parameters_from_overrides(true)
//   );

//   // Create the PandaMotionController
//   PandaMotionController motion_controller(node);

//   // Set the home state as the initial robot configuration
//   motion_controller.setArmGoalState("test_pos");

//   // Move to goal state 1
//   motion_controller.setArmGoalState("goal_state1");
//   motion_controller.setHandGoalState("closed_gripper"); // Close gripper at goal state 1

//   // Move to goal state 2
//   motion_controller.setArmGoalState("goal_state2");
//   motion_controller.setHandGoalState("open_gripper"); // Open gripper at goal state 2

//   // Return to the home state
//   motion_controller.setArmGoalState("test_pos");

//   // Shutdown ROS
//   rclcpp::shutdown();
//   return 0;
// }



int main(int argc, char * argv[])
{
  // Initialize ROS and create the Node
  rclcpp::init(argc, argv);
  auto const node = std::make_shared<rclcpp::Node>(
    "hello_moveit",
    rclcpp::NodeOptions().automatically_declare_parameters_from_overrides(true)
  );

  // Create a ROS logger
  auto const logger = rclcpp::get_logger("hello_moveit");

  // Create the MoveIt MoveGroup Interface
  using moveit::planning_interface::MoveGroupInterface;
  auto move_group_interface = MoveGroupInterface(node, "panda_arm");
  auto gripper_interface = MoveGroupInterface(node, "panda_hand");
  // Set a target Pose

  move_group_interface.setNamedTarget("goal_state1");
  move_group_interface.move();


  gripper_interface.setNamedTarget("gripper_open");
  gripper_interface.move();


// // Execute the plan
// if(success) {
//   move_group_interface.execute(plan);
// } else {
//   RCLCPP_ERROR(logger, "Planing failed!");
// }

  // Shutdown ROS
  rclcpp::shutdown();
  return 0;
}